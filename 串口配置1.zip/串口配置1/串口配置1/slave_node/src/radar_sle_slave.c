/*
 * Radar + SLE slave node.
 * Role: run radar human-presence detection and write each radar result to the SLE master node.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "securec.h"
#include "errcode.h"
#include "soc_osal.h"
#include "app_init.h"
#include "common_def.h"
#include "debug_print.h"
#include "watchdog.h"

#include "sle_common.h"
#include "sle_device_discovery.h"
#include "sle_connection_manager.h"
#include "sle_ssap_client.h"

#include "lwip/netifapi.h"
#include "wifi_hotspot.h"
#include "wifi_hotspot_config.h"
#include "td_base.h"
#include "td_type.h"
#include "uart.h"
#include "radar_service.h"
#include "gpio.h"
#include "pinctrl.h"
#include "../tdma/tdma_sle_scheduler.h"

/************************** User configuration **************************/
/* Same slave firmware can be burned to many boards. The final node id is generated automatically. */
#ifndef RADAR_NODE_ID_BASE
#define RADAR_NODE_ID_BASE "slave"
#endif

/* Must match the fixed SLE address used by the master advertising code. */
static uint8_t g_sle_expected_master_addr[SLE_ADDR_LEN] = {0x05, 0x01, 0x06, 0x08, 0x06, 0x03};

/************************** Radar configuration **************************/
#define WIFI_INIT_WAIT_TIME 5000
#define WIFI_START_STA_DELAY 1000

#define RADAR_STATUS_CALI_ISO 4
#define RADAR_STATUS_QUERY_DELAY 5000

#define RADAR_DEFAULT_LOOP 8
#define RADAR_DEFAULT_PERIOD 5000
#define RADAR_DEFAULT_DBG_TYPE 1
#define RADAR_DEFAULT_WAVE 2

#define RADAR_API_RANGE_NEAR 100
#define RADAR_API_RANGE_MEDIUM 200

#define CONFIG_RED_LED_PIN 7
#define CONFIG_GREEN_LED_PIN 11
#define CONFIG_YELLOW_LED_PIN 10

#define RADAR_TASK_PRIO 24
#define RADAR_TASK_STACK_SIZE 0x1000

/************************** SLE configuration **************************/
#define SLE_MTU_SIZE_DEFAULT 300
#define SLE_SEEK_INTERVAL_DEFAULT 100
#define SLE_SEEK_WINDOW_DEFAULT 100
#define UUID_16BIT_LEN 2
#define UUID_128BIT_LEN 16
#define RADAR_SLE_PAYLOAD_MAX_LEN 128

#define TDMA_SLE_FRAME_SLOTS TDMA_SLE_MIN_FRAME_SLOTS
#define TDMA_SLE_SLOT_MS 500
#define TDMA_SLE_GUARD_MS 30
#define TDMA_SLE_JOIN_BURST_COUNT 3
#define TDMA_SLE_JOIN_BURST_INTERVAL_MS 120
#define TDMA_SLE_JOIN_REFRESH_MS 15000
#define TDMA_SLE_REQUIRE_SERIAL_NODE_ID 1
#define TDMA_SLE_SERIAL_WAIT_LOG_MS 1000
#define TDMA_SLE_UART_RX_DIAG_MS 5000
#define TDMA_SLE_UART_SCAN_BUS_MIN 0
#define TDMA_SLE_UART_SCAN_BUS_MAX 3
#define TDMA_SLE_UART_CONFIG_STACK_SIZE 0x1000
#define TDMA_SLE_UART_CONFIG_PRIO 26
#define TDMA_SLE_TASK_PRIO 25
#define TDMA_SLE_TASK_STACK_SIZE 0x1000

#define SLE_CLIENT_TASK_PRIO 24
#define SLE_CLIENT_STACK_SIZE 0x2000

static sle_announce_seek_callbacks_t g_seek_cbk = {0};
static sle_connection_callbacks_t g_connect_cbk = {0};
static ssapc_callbacks_t g_ssapc_cbk = {0};
static sle_addr_t g_remote_addr = {0};
static sle_addr_t g_sle_local_addr = {0};
static uint16_t g_conn_id = 0xFFFF;
static uint16_t g_radar_property_handle = 0;
static bool g_sle_ready = false;
static unsigned long g_radar_report_seq = 0;
static unsigned long g_radar_write_fail_count = 0;
static uint8_t g_latest_human = 0;
static uint16_t g_latest_lower_boundary = 0;
static uint16_t g_latest_upper_boundary = 0;
static bool g_latest_radar_valid = false;
static tdma_sle_scheduler_t g_tdma_sched;
static volatile uint32_t g_tdma_tick_ms = 0;
static uint8_t g_tdma_my_slot = TDMA_SLE_INVALID_SLOT;
static uint8_t g_tdma_frame_slots = TDMA_SLE_FRAME_SLOTS;
static bool g_tdma_joined = false;
static volatile uint32_t g_last_join_ms = 0;
static char g_radar_node_id[TDMA_SLE_MAX_NODE_ID_LEN] = {0};
static uint32_t g_node_identity_token = 0;
static bool g_node_identity_ready = false;
static char g_uart_config_node_id[TDMA_SLE_MAX_NODE_ID_LEN] = {0};
static bool g_uart_config_ready = false;
static bool g_slave_runtime_started = false;

static uint32_t tdma_slave_hash32(const char *s)
{
    uint32_t hash = 2166136261UL;
    const unsigned char *p = (const unsigned char *)s;
    while (p != NULL && *p != '\0') {
        hash ^= (uint32_t)(*p++);
        hash *= 16777619UL;
    }
    return hash;
}

static bool tdma_slave_is_node_id_char(char c)
{
    return ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') ||
            (c >= 'a' && c <= 'z') || c == '_' || c == '-');
}

static void tdma_slave_sanitize_node_id(char *s)
{
    if (s == NULL) {
        return;
    }
    /*
     * Never replace bad bytes with '_' here.  The serial input shares the
     * debug/AT console on some boards, so echoed data or the next command can
     * be concatenated into the same RX buffer.  Truncating at the first
     * non-node-id byte prevents IDs such as "slave_01N" from being locked.
     */
    for (uint8_t i = 0; s[i] != '\0'; i++) {
        if (!tdma_slave_is_node_id_char(s[i])) {
            s[i] = '\0';
            return;
        }
    }
}

static void radar_node_identity_apply_token(uint32_t token, const char *node_id, const char *reason)
{
    g_node_identity_token = token & 0x00FFFFFFUL;
    if (g_node_identity_token == 0U) {
        g_node_identity_token = 0x000001UL;
    }

    if (node_id != NULL && node_id[0] != '\0') {
        (void)snprintf(g_radar_node_id, sizeof(g_radar_node_id), "%s", node_id);
        tdma_slave_sanitize_node_id(g_radar_node_id);
    } else {
        (void)snprintf(g_radar_node_id, sizeof(g_radar_node_id),
                       "%s_%06lX", RADAR_NODE_ID_BASE, (unsigned long)g_node_identity_token);
    }

    g_sle_local_addr.type = 0;
    g_sle_local_addr.addr[0] = 0x15;
    g_sle_local_addr.addr[1] = 0x01;
    g_sle_local_addr.addr[2] = (uint8_t)((g_node_identity_token >> 16) & 0xFFU);
    g_sle_local_addr.addr[3] = (uint8_t)((g_node_identity_token >> 8) & 0xFFU);
    g_sle_local_addr.addr[4] = (uint8_t)(g_node_identity_token & 0xFFU);
    g_sle_local_addr.addr[5] = (uint8_t)(tdma_slave_hash32(g_radar_node_id) & 0xFFU);

    g_tdma_my_slot = TDMA_SLE_INVALID_SLOT;
    g_tdma_frame_slots = TDMA_SLE_FRAME_SLOTS;
    g_tdma_joined = false;
    g_node_identity_ready = true;

    PRINT("[SLAVE TDMA][ID] reason=%s node=%s token=0x%06lX local_addr=%02x:%02x:%02x:%02x:%02x:%02x slot=unassigned\r\n",
          (reason == NULL) ? "auto" : reason,
          g_radar_node_id,
          (unsigned long)g_node_identity_token,
          g_sle_local_addr.addr[0], g_sle_local_addr.addr[1], g_sle_local_addr.addr[2],
          g_sle_local_addr.addr[3], g_sle_local_addr.addr[4], g_sle_local_addr.addr[5]);
}

static uint32_t tdma_slave_xorshift32(uint32_t x)
{
    if (x == 0U) {
        x = 0xA5C35A5AU;
    }
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

static uint32_t tdma_slave_collect_entropy(void)
{
    uint32_t seed = 0x534C4531UL;
    seed ^= (uint32_t)(uintptr_t)&seed;
    seed ^= (uint32_t)(uintptr_t)&g_tdma_sched;
    seed ^= (uint32_t)(uintptr_t)&g_remote_addr;
    seed ^= (uint32_t)g_tdma_tick_ms * 1103515245UL;
    seed ^= ((uint32_t)g_latest_lower_boundary << 16) ^ g_latest_upper_boundary;
    seed ^= ((uint32_t)g_latest_human << 24) ^ ((uint32_t)g_latest_radar_valid << 23);
    seed ^= (uint32_t)g_radar_report_seq * 2654435761UL;
    seed ^= (uint32_t)g_conn_id << 8;
    return tdma_slave_xorshift32(seed);
}

static void radar_node_identity_init(const char *reason)
{
    if (g_node_identity_ready) {
        return;
    }

#if defined(RADAR_NODE_ID_CONFIG)
    if (!g_uart_config_ready) {
        (void)snprintf(g_uart_config_node_id, sizeof(g_uart_config_node_id), "%s", RADAR_NODE_ID_CONFIG);
        tdma_slave_sanitize_node_id(g_uart_config_node_id);
        g_uart_config_ready = (g_uart_config_node_id[0] != '\0');
    }
#endif

    if (g_uart_config_ready) {
        radar_node_identity_apply_token(tdma_slave_hash32(g_uart_config_node_id),
                                        g_uart_config_node_id,
                                        (reason == NULL) ? "serial_config" : reason);
        return;
    }

    uint32_t token = tdma_slave_collect_entropy();
    for (uint8_t i = 0; i < 4; i++) {
        token = tdma_slave_xorshift32(token ^ (0x9E3779B9UL + i + g_tdma_tick_ms));
    }
    radar_node_identity_apply_token(token, NULL, reason);
}

static const char *radar_node_id(void)
{
    if (!g_node_identity_ready) {
        radar_node_identity_init("lazy");
    }
    return g_radar_node_id;
}


static void radar_slave_start_runtime_tasks(void);
static void radar_slave_apply_serial_config_line(char *line);

static bool radar_slave_extract_node_id(const char *line, char *node_id, uint32_t node_id_len)
{
    if (line == NULL || node_id == NULL || node_id_len == 0) {
        return false;
    }
    node_id[0] = '\0';

    const char *node_cmd = strstr(line, "NODE=");
    uint32_t prefix_len = 5;
    if (node_cmd == NULL) {
        node_cmd = strstr(line, "node=");
    }
    if (node_cmd == NULL) {
        node_cmd = strstr(line, "SLAVE,id=");
        prefix_len = 9;
    }
    if (node_cmd == NULL) {
        return false;
    }

    const char *value = node_cmd + prefix_len;
    while (*value == ' ' || *value == '\t') {
        value++;
    }

    uint32_t out = 0;
    while (*value != '\0' && out < (node_id_len - 1U)) {
        char c = *value++;
        if (!tdma_slave_is_node_id_char(c)) {
            break;
        }
        node_id[out++] = c;
    }
    node_id[out] = '\0';

    tdma_slave_sanitize_node_id(node_id);
    return (node_id[0] != '\0');
}

static bool radar_slave_try_exact_node_commit(char *line)
{
    if (line == NULL || g_uart_config_ready || g_node_identity_ready || g_conn_id != 0xFFFF || g_sle_ready) {
        return false;
    }

    char *cmd = strstr(line, "NODE=");
    if (cmd == NULL) {
        cmd = strstr(line, "node=");
    }
    if (cmd == NULL) {
        return false;
    }

    char *value = cmd + 5;
    if (strncmp(value, "slave_", 6) != 0) {
        return false;
    }

    if (tdma_slave_is_node_id_char(value[6]) && tdma_slave_is_node_id_char(value[7])) {
        char tmp[TDMA_SLE_MAX_NODE_ID_LEN + 8] = {0};
        (void)snprintf(tmp, sizeof(tmp), "NODE=%.*s", 8, value);
        radar_slave_apply_serial_config_line(tmp);
        return g_uart_config_ready;
    }
    return false;
}

static void radar_slave_apply_serial_config_line(char *line)
{
    if (line == NULL) {
        return;
    }

    char node_id[TDMA_SLE_MAX_NODE_ID_LEN] = {0};
    if (!radar_slave_extract_node_id(line, node_id, sizeof(node_id))) {
        PRINT("[SLAVE CFG] unsupported/bad command: %s; Use: NODE=slave_01\r\n", line);
        return;
    }

    if (g_node_identity_ready || g_conn_id != 0xFFFF || g_sle_ready) {
        PRINT("[SLAVE CFG] node id already locked as %s; reboot to change serial config\r\n", radar_node_id());
        return;
    }

    (void)snprintf(g_uart_config_node_id, sizeof(g_uart_config_node_id), "%s", node_id);
    tdma_slave_sanitize_node_id(g_uart_config_node_id);
    if (g_uart_config_node_id[0] == '\0') {
        PRINT("[SLAVE CFG] empty node id ignored\r\n");
        return;
    }

    g_uart_config_ready = true;
    PRINT("[SLAVE CFG] serial node id configured: %s\r\n", g_uart_config_node_id);
    radar_slave_start_runtime_tasks();
}

#ifndef TDMA_SLE_CFG_UART_BUS
#ifdef CONFIG_UART_BUS_ID
#define TDMA_SLE_CFG_UART_BUS CONFIG_UART_BUS_ID
#else
#define TDMA_SLE_CFG_UART_BUS UART_BUS_0
#endif
#endif

static int radar_slave_uart_config_task(const char *arg)
{
    unused(arg);
    char line[64] = {0};
    uint32_t pos = 0;
    uint32_t idle_ms = 0;
    uint32_t diag_ms = 0;
    bool ever_rx = false;

    PRINT("[SLAVE CFG] serial config ready. Send NODE=<unique_slave_id> before SLE enable.\r\n");
    PRINT("[SLAVE CFG] polling UART buses %d..%d; exact NODE=slave_xx is committed immediately, CR/LF or 300ms idle also commits.\r\n",
          TDMA_SLE_UART_SCAN_BUS_MIN, TDMA_SLE_UART_SCAN_BUS_MAX);
    PRINT("[SLAVE CFG] if NODE appears only as echo and this task prints no rx line, input is captured by AT/console, not app UART.\r\n");

    while (1) {
        uint8_t ch = 0;
        int32_t rx_len = 0;
        int rx_bus = -1;

        for (int bus = TDMA_SLE_UART_SCAN_BUS_MIN; bus <= TDMA_SLE_UART_SCAN_BUS_MAX; bus++) {
            rx_len = (int32_t)uapi_uart_read(bus, &ch, 1, 0);
            if (rx_len > 0) {
                rx_bus = bus;
                break;
            }
        }

        if (rx_len <= 0) {
            osal_msleep(20);
            diag_ms += 20;
            if (!ever_rx && diag_ms >= TDMA_SLE_UART_RX_DIAG_MS) {
                diag_ms = 0;
                PRINT("[SLAVE CFG] no UART RX bytes captured by app task yet; at_recv increasing means AT/console owns this serial input.\r\n");
            }
            if (pos > 0) {
                idle_ms += 20;
                if (idle_ms >= 300) {
                    line[pos] = '\0';
                    PRINT("[SLAVE CFG] rx idle commit: %s\r\n", line);
                    radar_slave_apply_serial_config_line(line);
                    if (g_uart_config_ready) {
                        PRINT("[SLAVE CFG] config task exit, node=%s\r\n", g_uart_config_node_id);
                        return 0;
                    }
                    (void)memset_s(line, sizeof(line), 0, sizeof(line));
                    pos = 0;
                    idle_ms = 0;
                }
            }
            continue;
        }

        ever_rx = true;
        diag_ms = 0;
        idle_ms = 0;
        if (ch == '\r' || ch == '\n') {
            if (pos > 0) {
                line[pos] = '\0';
                PRINT("[SLAVE CFG] rx line bus=%d: %s\r\n", rx_bus, line);
                radar_slave_apply_serial_config_line(line);
                if (g_uart_config_ready) {
                    PRINT("[SLAVE CFG] config task exit, node=%s\r\n", g_uart_config_node_id);
                    return 0;
                }
                (void)memset_s(line, sizeof(line), 0, sizeof(line));
                pos = 0;
            }
            continue;
        }

        if (pos < (sizeof(line) - 1)) {
            line[pos++] = (char)ch;
            line[pos] = '\0';
            if (radar_slave_try_exact_node_commit(line)) {
                PRINT("[SLAVE CFG] exact NODE command accepted, node=%s\r\n", g_uart_config_node_id);
                return 0;
            }
        } else {
            line[sizeof(line) - 1] = '\0';
            PRINT("[SLAVE CFG] command too long bus=%d, drop: %s\r\n", rx_bus, line);
            (void)memset_s(line, sizeof(line), 0, sizeof(line));
            pos = 0;
            idle_ms = 0;
        }
    }
    return 0;
}

static void sle_start_scan(void);

/************************** SLE report sender **************************/
static errcode_t radar_sle_write_payload(const char *payload)
{
    ssapc_write_param_t param = {0};

    PRINT("[SLAVE SLE] before send ready=%d conn=0x%x handle=0x%x seq=%lu payload=%p\r\n",
          g_sle_ready, g_conn_id, g_radar_property_handle, g_radar_report_seq, payload);

    if (!g_sle_ready || g_conn_id == 0xFFFF || g_radar_property_handle == 0 || payload == NULL) {
        g_radar_write_fail_count++;
        PRINT("[SLAVE SLE] drop payload, ready=%d conn=0x%x handle=0x%x payload=%p fail_count=%lu\r\n",
              g_sle_ready, g_conn_id, g_radar_property_handle, payload, g_radar_write_fail_count);
        return ERRCODE_FAIL;
    }

    param.handle = g_radar_property_handle;
    param.type = SSAP_PROPERTY_TYPE_VALUE;
    param.data_len = (uint16_t)strlen(payload);
    param.data = (uint8_t *)payload;

    PRINT("[SLAVE SLE] write radar payload conn:0x%x handle:0x%x len:%u data:%s\r\n",
          g_conn_id, g_radar_property_handle, param.data_len, payload);
    errcode_t ret = ssapc_write_req(0, g_conn_id, &param);
    PRINT("[SLAVE SLE] write req ret:0x%x\r\n", ret);
    if (ret != ERRCODE_SUCC) {
        g_radar_write_fail_count++;
        PRINT("[SLAVE SLE] write req failed ret:0x%x fail_count=%lu\r\n", ret, g_radar_write_fail_count);
    }
    return ret;
}

static void tdma_sle_wait_until_slot(uint8_t target_slot)
{
    g_tdma_sched.frame_slots = g_tdma_frame_slots;
    uint32_t delay_ms = tdma_sle_next_slot_delay_ms(&g_tdma_sched, g_tdma_tick_ms, target_slot);
    uint32_t sleep_ms = (delay_ms > TDMA_SLE_GUARD_MS) ?
                        (delay_ms + TDMA_SLE_GUARD_MS) : TDMA_SLE_GUARD_MS;
    osal_msleep(sleep_ms);
    g_tdma_tick_ms += sleep_ms;
}

static void tdma_sle_wait_until_my_slot(void)
{
    if (g_tdma_my_slot == TDMA_SLE_INVALID_SLOT) {
        g_tdma_my_slot = tdma_sle_hash_slot(radar_node_id(), TDMA_SLE_FRAME_SLOTS);
    }

    tdma_sle_wait_until_slot(g_tdma_my_slot);
}

static void radar_sle_send_join_report(void)
{
    char payload[RADAR_SLE_PAYLOAD_MAX_LEN] = {0};
    unsigned long next_seq = g_radar_report_seq + 1;

    if (g_tdma_my_slot == TDMA_SLE_INVALID_SLOT) {
        g_tdma_my_slot = tdma_sle_hash_slot(radar_node_id(), TDMA_SLE_FRAME_SLOTS);
    }

    tdma_sle_wait_until_slot(TDMA_SLE_MASTER_SLOT);

    (void)tdma_sle_make_join_payload(payload,
                                     sizeof(payload),
                                     radar_node_id(),
                                     (uint32_t)next_seq,
                                     TDMA_SLE_MASTER_SLOT,
                                     g_tdma_frame_slots,
                                     TDMA_SLE_SLOT_MS);
    PRINT("[SLAVE TDMA] join try node=%s request_slot=0 preferred_slot=%u seq=%lu tick=%lu\r\n",
          radar_node_id(), g_tdma_my_slot, next_seq, (unsigned long)g_tdma_tick_ms);
    if (radar_sle_write_payload(payload) == ERRCODE_SUCC) {
        g_radar_report_seq = next_seq;
        g_last_join_ms = g_tdma_tick_ms;
    }
}

static void radar_sle_send_report(uint8_t human, uint16_t lower_boundary, uint16_t upper_boundary)
{
    char payload[RADAR_SLE_PAYLOAD_MAX_LEN] = {0};
    unsigned long next_seq = g_radar_report_seq + 1;

    if (g_tdma_my_slot == TDMA_SLE_INVALID_SLOT) {
        g_tdma_my_slot = tdma_sle_hash_slot(radar_node_id(), TDMA_SLE_FRAME_SLOTS);
    }

    (void)tdma_sle_make_radar_payload(payload,
                                      sizeof(payload),
                                      radar_node_id(),
                                      g_tdma_my_slot,
                                      g_tdma_frame_slots,
                                      human,
                                      lower_boundary,
                                      upper_boundary,
                                      (uint32_t)next_seq);

    PRINT("[SLAVE TDMA] report try seq=%lu slot=%u human=%u range=%u-%u ready=%d\r\n",
          next_seq, g_tdma_my_slot, human, lower_boundary, upper_boundary, g_sle_ready);
    if (radar_sle_write_payload(payload) == ERRCODE_SUCC) {
        g_radar_report_seq = next_seq;
        PRINT("[SLAVE SLE] tdma write ok, seq=%lu slot=%u\r\n", g_radar_report_seq, g_tdma_my_slot);
    }
}

static void radar_sle_send_online_report(void)
{
    for (uint8_t i = 0; i < TDMA_SLE_JOIN_BURST_COUNT; i++) {
        radar_sle_send_join_report();
        osal_msleep(TDMA_SLE_JOIN_BURST_INTERVAL_MS);
        g_tdma_tick_ms += TDMA_SLE_JOIN_BURST_INTERVAL_MS;
    }
}

static void tdma_sle_refresh_join_if_needed(void)
{
    if (!g_sle_ready) {
        return;
    }
    if (!g_tdma_joined || g_last_join_ms == 0U || (g_tdma_tick_ms - g_last_join_ms) >= TDMA_SLE_JOIN_REFRESH_MS) {
        radar_sle_send_join_report();
    }
}
/************************** Radar helpers **************************/
typedef struct {
    uint8_t times;
    uint8_t loop;
    uint8_t ant;
    uint8_t wave;
    uint8_t dbg_type;
    uint16_t period;
} radar_driver_para_t;

static void gpio_set_value(pin_t pin)
{
    uapi_pin_set_mode(pin, HAL_PIO_FUNC_GPIO);
    uapi_gpio_set_dir(pin, GPIO_DIRECTION_OUTPUT);
}

static void radar_led_init(void)
{
    PRINT("[SLAVE RADAR] LED init pins R=%d G=%d Y=%d\r\n",
          CONFIG_RED_LED_PIN, CONFIG_GREEN_LED_PIN, CONFIG_YELLOW_LED_PIN);
    uapi_gpio_init();
    gpio_set_value(CONFIG_RED_LED_PIN);
    gpio_set_value(CONFIG_GREEN_LED_PIN);
    gpio_set_value(CONFIG_YELLOW_LED_PIN);
}

static void radar_switch_green_on_off(bool onoff)
{
    uapi_gpio_set_val(CONFIG_GREEN_LED_PIN, onoff ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
}

static void radar_switch_yellow_on_off(bool onoff)
{
    uapi_gpio_set_val(CONFIG_YELLOW_LED_PIN, onoff ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
}

static void radar_switch_red_on_off(bool onoff)
{
    uapi_gpio_set_val(CONFIG_RED_LED_PIN, onoff ? GPIO_LEVEL_LOW : GPIO_LEVEL_HIGH);
}

static void radar_ctrl_led(radar_result_t *res)
{
    if (res == NULL) {
        return;
    }

    PRINT("[SLAVE RADAR] LED update human=%u range=%u-%u\r\n",
          res->is_human_presence, res->lower_boundary, res->upper_boundary);
    radar_switch_green_on_off(res->is_human_presence ? true : false);

    if (res->lower_boundary == 0 && res->upper_boundary == RADAR_API_RANGE_NEAR) {
        radar_switch_red_on_off(true);
        radar_switch_yellow_on_off(true);
    } else if (res->lower_boundary == RADAR_API_RANGE_NEAR && res->upper_boundary == RADAR_API_RANGE_MEDIUM) {
        radar_switch_red_on_off(false);
        radar_switch_yellow_on_off(true);
    } else {
        radar_switch_red_on_off(false);
        radar_switch_yellow_on_off(false);
    }
}

static errcode_t radar_start_sta(void)
{
    osal_msleep(WIFI_INIT_WAIT_TIME);
    printf("[SLAVE RADAR] STA try enable for radar\r\n");
    if (wifi_sta_enable() != 0) {
        printf("[SLAVE RADAR] sta enable failed\r\n");
        return ERRCODE_FAIL;
    }
    printf("[SLAVE RADAR] STA enabled\r\n");
    return ERRCODE_SUCC;
}

static void radar_result_cb(radar_result_t *res)
{
    if (res == NULL) {
        return;
    }

    g_latest_human = res->is_human_presence;
    g_latest_lower_boundary = res->lower_boundary;
    g_latest_upper_boundary = res->upper_boundary;
    g_latest_radar_valid = true;

    printf("[SLAVE RADAR] lb:%u, hb:%u, human:%u, latest updated\r\n",
           g_latest_lower_boundary,
           g_latest_upper_boundary,
           g_latest_human);

    radar_ctrl_led(res);
}

static void radar_init_para(void)
{
    radar_dbg_para_t dbg_para;
    dbg_para.times = 0;
    dbg_para.loop = RADAR_DEFAULT_LOOP;
    dbg_para.ant = 0;
    dbg_para.wave = RADAR_DEFAULT_WAVE;
    dbg_para.dbg_type = RADAR_DEFAULT_DBG_TYPE;
    dbg_para.period = RADAR_DEFAULT_PERIOD;
    uapi_radar_set_debug_para(&dbg_para);

    radar_sel_para_t sel_para;
    sel_para.height = 0;
    sel_para.scenario = 0;
    sel_para.material = 2;
    sel_para.fusion_track = 1;
    sel_para.fusion_ai = 1;
    uapi_radar_select_alg_para(&sel_para);

    radar_alg_para_t alg_para;
    alg_para.d_th_1m = 32;
    alg_para.d_th_2m = 27;
    alg_para.p_th = 30;
    alg_para.t_th_1m = 13;
    alg_para.t_th_2m = 26;
    alg_para.b_th_ratio = 50;
    alg_para.b_th_cnt = 15;
    alg_para.a_th = 70;
    uapi_radar_set_alg_para(&alg_para, 0);
}

static int radar_task(const char *arg)
{
    unused(arg);
    printf("[SLAVE RADAR] init\r\n");

    radar_led_init();
    if (radar_start_sta() != ERRCODE_SUCC) {
        printf("[SLAVE RADAR] STA init failed, continue radar init\r\n");
    }
    uapi_radar_register_result_cb(radar_result_cb);
    printf("[SLAVE RADAR] result callback registered\r\n");
    radar_init_para();
    printf("[SLAVE RADAR] radar parameters configured\r\n");

    osal_msleep(WIFI_START_STA_DELAY);
    uapi_radar_set_status(RADAR_STATUS_CALI_ISO);
    printf("[SLAVE RADAR] set status CALI_ISO=%d\r\n", RADAR_STATUS_CALI_ISO);

    while (1) {
        uapi_radar_set_delay_time(8);
        osal_msleep(RADAR_STATUS_QUERY_DELAY);
        uint8_t sts;
        uint16_t time;
        uint16_t iso;
        uapi_radar_get_status(&sts);
        uapi_radar_get_delay_time(&time);
        uapi_radar_get_isolation(&iso);
        printf("[SLAVE RADAR] status=%u delay=%u isolation=%u sle_ready=%d seq=%lu latest_valid=%d human=%u lb=%u hb=%u\r\n",
               sts, time, iso, g_sle_ready, g_radar_report_seq, g_latest_radar_valid,
               g_latest_human, g_latest_lower_boundary, g_latest_upper_boundary);

        if (g_sle_ready) {
            tdma_sle_refresh_join_if_needed();
            if (!g_tdma_joined || g_tdma_my_slot == TDMA_SLE_INVALID_SLOT) {
                printf("[SLAVE TDMA] waiting for master ASSIGN before radar report\r\n");
                continue;
            }
            tdma_sle_wait_until_my_slot();
            if (g_latest_radar_valid) {
                printf("[SLAVE RADAR] periodic report latest data\r\n");
                radar_sle_send_report(g_latest_human, g_latest_lower_boundary, g_latest_upper_boundary);
            } else {
                printf("[SLAVE RADAR] periodic report default data, no radar callback yet\r\n");
                radar_sle_send_report(0, 0, 0);
            }
        } else {
            printf("[SLAVE RADAR] periodic report skipped, SLE not ready seq=%lu\r\n", g_radar_report_seq);
        }
    }

    return 0;
}

static void sle_start_exchange_info(uint16_t conn_id)
{
    ssap_exchange_info_t info = {0};
    info.mtu_size = SLE_MTU_SIZE_DEFAULT;
    info.version = 1;
    errcode_t ret = ssapc_exchange_info_req(0, conn_id, &info);
    PRINT("[SLAVE SLE] exchange info req ret:0x%x mtu:%u conn:0x%x\r\n", ret, info.mtu_size, conn_id);
}

/************************** SLE client callbacks **************************/
static void sle_enable_cbk(errcode_t status)
{
    PRINT("[SLAVE SLE] enable cb status:0x%x\r\n", status);
    if (status == ERRCODE_SUCC) {
        radar_node_identity_init("enable_cb");
        errcode_t addr_ret = sle_set_local_addr(&g_sle_local_addr);
        PRINT("[SLAVE SLE] set local addr after enable ret:0x%x node=%s addr=%02x:%02x:%02x:%02x:%02x:%02x\r\n",
              addr_ret, radar_node_id(),
              g_sle_local_addr.addr[0], g_sle_local_addr.addr[1], g_sle_local_addr.addr[2],
              g_sle_local_addr.addr[3], g_sle_local_addr.addr[4], g_sle_local_addr.addr[5]);
        sle_start_scan();
    }
}

static void sle_seek_enable_cbk(errcode_t status)
{
    PRINT("[SLAVE SLE] seek enable status:0x%x\r\n", status);
    if (status == ERRCODE_SUCC) {
        PRINT("[SLAVE SLE] scanning master\r\n");
    }
}

static void sle_seek_disable_cbk(errcode_t status)
{
    PRINT("[SLAVE SLE] seek disable status:0x%x\r\n", status);
    if (status == ERRCODE_SUCC) {
        PRINT("[SLAVE SLE] connect master\r\n");
        errcode_t ret = sle_connect_remote_device(&g_remote_addr);
        PRINT("[SLAVE SLE] connect request ret:0x%x\r\n", ret);
        if (ret != ERRCODE_SUCC) {
            PRINT("[SLAVE SLE] connect request failed, restart scan\r\n");
            osal_msleep(300);
            sle_start_scan();
        }
    }
}

static void sle_seek_result_info_cbk(sle_seek_result_info_t *seek_result_data)
{
    if (seek_result_data == NULL) {
        return;
    }

    if (g_conn_id != 0xFFFF || g_sle_ready) {
        return;
    }

    if (memcmp(seek_result_data->addr.addr, g_sle_expected_master_addr, SLE_ADDR_LEN) == 0) {
        PRINT("[SLAVE SLE] found master addr:%02x:**:**:**:%02x:%02x\r\n",
              seek_result_data->addr.addr[0], seek_result_data->addr.addr[4], seek_result_data->addr.addr[5]);
        (void)memcpy_s(&g_remote_addr, sizeof(sle_addr_t), &seek_result_data->addr, sizeof(sle_addr_t));
        errcode_t ret = sle_stop_seek();
        PRINT("[SLAVE SLE] stop seek ret:0x%x\r\n", ret);
    }
}

static void sle_seek_cbk_register(void)
{
    g_seek_cbk.sle_enable_cb = sle_enable_cbk;
    g_seek_cbk.seek_enable_cb = sle_seek_enable_cbk;
    g_seek_cbk.seek_disable_cb = sle_seek_disable_cbk;
    g_seek_cbk.seek_result_cb = sle_seek_result_info_cbk;
}

static void sle_connect_state_changed_cbk(uint16_t conn_id,
                                          const sle_addr_t *addr,
                                          sle_acb_state_t conn_state,
                                          sle_pair_state_t pair_state,
                                          sle_disc_reason_t disc_reason)
{
    if (addr != NULL) {
        PRINT("[SLAVE SLE] conn state conn_id:0x%x state:0x%x pair:0x%x reason:0x%x addr:%02x:**:**:**:%02x:%02x\r\n",
              conn_id, conn_state, pair_state, disc_reason, addr->addr[0], addr->addr[4], addr->addr[5]);
    } else {
        PRINT("[SLAVE SLE] conn state conn_id:0x%x state:0x%x pair:0x%x reason:0x%x addr:null\r\n",
              conn_id, conn_state, pair_state, disc_reason);
    }

    if (conn_state == SLE_ACB_STATE_CONNECTED) {
        g_conn_id = conn_id;
        g_sle_ready = false;
        g_radar_property_handle = 0;
        if (pair_state == SLE_PAIR_NONE) {
            errcode_t ret = sle_pair_remote_device(&g_remote_addr);
            PRINT("[SLAVE SLE] pair request ret:0x%x\r\n", ret);
        } else {
            PRINT("[SLAVE SLE] already paired, start exchange/discovery directly\r\n");
            sle_start_exchange_info(conn_id);
        }
    } else {
        g_sle_ready = false;
        g_conn_id = 0xFFFF;
        g_radar_property_handle = 0;
        g_last_join_ms = 0;
        g_tdma_joined = false;
        g_tdma_my_slot = TDMA_SLE_INVALID_SLOT;
        PRINT("[SLAVE SLE] disconnected, reason=0x%x, restart scan\r\n", disc_reason);
        osal_msleep(500);
        sle_start_scan();
    }
}

static void sle_pair_complete_cbk(uint16_t conn_id, const sle_addr_t *addr, errcode_t status)
{
    PRINT("[SLAVE SLE] pair complete conn_id:0x%x status:0x%x addr:%02x:**:**:**:%02x:%02x\r\n",
          conn_id, status, addr->addr[0], addr->addr[4], addr->addr[5]);

    if (status == ERRCODE_SUCC) {
        sle_start_exchange_info(conn_id);
    }
}

static void sle_connect_cbk_register(void)
{
    g_connect_cbk.connect_state_changed_cb = sle_connect_state_changed_cbk;
    g_connect_cbk.pair_complete_cb = sle_pair_complete_cbk;
}

static void sle_exchange_info_cbk(uint8_t client_id,
                                  uint16_t conn_id,
                                  ssap_exchange_info_t *param,
                                  errcode_t status)
{
    if (param == NULL) {
        PRINT("[SLAVE SLE] exchange info null param status:0x%x\r\n", status);
        return;
    }
    PRINT("[SLAVE SLE] exchange info client:0x%x conn:0x%x mtu:0x%x version:0x%x status:0x%x\r\n",
          client_id, conn_id, param->mtu_size, param->version, status);

    if (status == ERRCODE_SUCC) {
        ssapc_find_structure_param_t find_param = {0};
        find_param.type = SSAP_FIND_TYPE_PROPERTY;
        find_param.start_hdl = 1;
        find_param.end_hdl = 0xFFFF;
        errcode_t ret = ssapc_find_structure(0, conn_id, &find_param);
        PRINT("[SLAVE SLE] find structure req ret:0x%x conn:0x%x\r\n", ret, conn_id);
    }
}

static void sle_find_structure_cbk(uint8_t client_id,
                                   uint16_t conn_id,
                                   ssapc_find_service_result_t *service,
                                   errcode_t status)
{
    unused(client_id);
    unused(conn_id);
    PRINT("[SLAVE SLE] find structure status:0x%x start:0x%x end:0x%x uuid_len:%u\r\n",
          status, service->start_hdl, service->end_hdl, service->uuid.len);
}

static void sle_find_structure_cmp_cbk(uint8_t client_id,
                                       uint16_t conn_id,
                                       ssapc_find_structure_result_t *structure_result,
                                       errcode_t status)
{
    unused(client_id);
    unused(conn_id);
    PRINT("[SLAVE SLE] find structure cmp status:0x%x type:%d uuid_len:%u\r\n",
          status, structure_result->type, structure_result->uuid.len);
}

static void sle_find_property_cbk(uint8_t client_id,
                                  uint16_t conn_id,
                                  ssapc_find_property_result_t *property,
                                  errcode_t status)
{
    if (property == NULL) {
        PRINT("[SLAVE SLE] find property null status:0x%x\r\n", status);
        return;
    }
    PRINT("[SLAVE SLE] find property client:0x%x conn:0x%x handle:0x%x status:0x%x uuid_len:%u\r\n",
          client_id, conn_id, property->handle, status, property->uuid.len);

    if (status == ERRCODE_SUCC) {
        g_radar_property_handle = property->handle;
        g_sle_ready = true;
        PRINT("[SLAVE SLE] radar property ready handle:0x%x\r\n", g_radar_property_handle);
        radar_sle_send_online_report();
    }
}

static void tdma_slave_handle_control_payload(const char *payload)
{
    if (payload == NULL || payload[0] == '\0') {
        return;
    }

    char node_id[TDMA_SLE_MAX_NODE_ID_LEN] = {0};
    uint8_t slot = TDMA_SLE_INVALID_SLOT;
    uint8_t frame_slots = TDMA_SLE_FRAME_SLOTS;
    if (tdma_sle_parse_assign_payload(payload, node_id, sizeof(node_id), &slot, &frame_slots)) {
        if (strcmp(node_id, radar_node_id()) != 0) {
            PRINT("[SLAVE TDMA][ASSIGN] ignore response for node=%s local=%s\r\n", node_id, radar_node_id());
            return;
        }
        if (slot == TDMA_SLE_MASTER_SLOT || slot == TDMA_SLE_INVALID_SLOT) {
            PRINT("[SLAVE TDMA][ASSIGN] invalid slot=%u payload=%s\r\n", slot, payload);
            return;
        }
        g_tdma_my_slot = slot;
        g_tdma_frame_slots = (frame_slots < TDMA_SLE_MIN_FRAME_SLOTS) ? TDMA_SLE_MIN_FRAME_SLOTS : frame_slots;
        if (g_tdma_frame_slots > TDMA_SLE_MAX_FRAME_SLOTS) {
            g_tdma_frame_slots = TDMA_SLE_MAX_FRAME_SLOTS;
        }
        g_tdma_sched.frame_slots = g_tdma_frame_slots;
        g_tdma_joined = true;
        PRINT("[SLAVE TDMA][ASSIGN] joined node=%s slot=%u frame_slots=%u\r\n",
              radar_node_id(), g_tdma_my_slot, g_tdma_frame_slots);
        return;
    }

    if (memcmp(payload, "RADARACK,", strlen("RADARACK,")) == 0) {
        PRINT("[SLAVE TDMA][ACK] %s\r\n", payload);
    }
}

static void sle_write_cfm_cbk(uint8_t client_id,
                              uint16_t conn_id,
                              ssapc_write_result_t *write_result,
                              errcode_t status)
{
    if (write_result == NULL) {
        PRINT("[SLAVE SLE] write confirm null client:0x%x conn:0x%x status:0x%x\r\n", client_id, conn_id, status);
        return;
    }
    PRINT("[SLAVE SLE] write confirm client:0x%x conn:0x%x handle:0x%x status:0x%x\r\n",
          client_id, conn_id, write_result->handle, status);
}

static void sle_read_cfm_cbk(uint8_t client_id,
                             uint16_t conn_id,
                             ssapc_handle_value_t *read_data,
                             errcode_t status)
{
    PRINT("[SLAVE SLE] read confirm client:0x%x conn:0x%x len:0x%x status:0x%x\r\n",
          client_id, conn_id, (read_data == NULL) ? 0 : read_data->data_len, status);
    if (status == ERRCODE_SUCC && read_data != NULL && read_data->data != NULL && read_data->data_len > 0) {
        char payload[RADAR_SLE_PAYLOAD_MAX_LEN] = {0};
        uint16_t len = (read_data->data_len >= RADAR_SLE_PAYLOAD_MAX_LEN) ? (RADAR_SLE_PAYLOAD_MAX_LEN - 1U) : read_data->data_len;
        (void)memcpy_s(payload, sizeof(payload), read_data->data, len);
        tdma_slave_handle_control_payload(payload);
    }
}

static void sle_notification_cbk(uint8_t client_id,
                                 uint16_t conn_id,
                                 ssapc_handle_value_t *data,
                                 errcode_t status)
{
    PRINT("[SLAVE SLE] notification client:0x%x conn:0x%x status:0x%x\r\n", client_id, conn_id, status);
    if (status == ERRCODE_SUCC && data != NULL && data->data != NULL && data->data_len > 0) {
        char payload[RADAR_SLE_PAYLOAD_MAX_LEN] = {0};
        uint16_t len = (data->data_len >= RADAR_SLE_PAYLOAD_MAX_LEN) ? (RADAR_SLE_PAYLOAD_MAX_LEN - 1U) : data->data_len;
        (void)memcpy_s(payload, sizeof(payload), data->data, len);
        tdma_slave_handle_control_payload(payload);
    }
}

static void sle_indication_cbk(uint8_t client_id,
                               uint16_t conn_id,
                               ssapc_handle_value_t *data,
                               errcode_t status)
{
    PRINT("[SLAVE SLE] indication client:0x%x conn:0x%x status:0x%x\r\n", client_id, conn_id, status);
    if (status == ERRCODE_SUCC && data != NULL && data->data != NULL && data->data_len > 0) {
        char payload[RADAR_SLE_PAYLOAD_MAX_LEN] = {0};
        uint16_t len = (data->data_len >= RADAR_SLE_PAYLOAD_MAX_LEN) ? (RADAR_SLE_PAYLOAD_MAX_LEN - 1U) : data->data_len;
        (void)memcpy_s(payload, sizeof(payload), data->data, len);
        tdma_slave_handle_control_payload(payload);
    }
}

static void sle_ssapc_cbk_register(void)
{
    g_ssapc_cbk.exchange_info_cb = sle_exchange_info_cbk;
    g_ssapc_cbk.find_structure_cb = sle_find_structure_cbk;
    g_ssapc_cbk.find_structure_cmp_cb = sle_find_structure_cmp_cbk;
    g_ssapc_cbk.ssapc_find_property_cbk = sle_find_property_cbk;
    g_ssapc_cbk.write_cfm_cb = sle_write_cfm_cbk;
    g_ssapc_cbk.read_cfm_cb = sle_read_cfm_cbk;
    g_ssapc_cbk.notification_cb = sle_notification_cbk;
    g_ssapc_cbk.indication_cb = sle_indication_cbk;
}

static void sle_start_scan(void)
{
    sle_seek_param_t param = {0};
    param.own_addr_type = 0;
    param.filter_duplicates = 0;
    param.seek_filter_policy = 0;
    param.seek_phys = 1;
    param.seek_type[0] = 0;
    param.seek_interval[0] = SLE_SEEK_INTERVAL_DEFAULT;
    param.seek_window[0] = SLE_SEEK_WINDOW_DEFAULT;
    errcode_t ret = sle_set_seek_param(&param);
    PRINT("[SLAVE SLE] set seek param ret:0x%x interval:%u window:%u\r\n",
          ret, param.seek_interval[0], param.seek_window[0]);
    ret = sle_start_seek();
    PRINT("[SLAVE SLE] start seek ret:0x%x\r\n", ret);
}

static int radar_sle_client_task(const char *arg)
{
    unused(arg);

#if TDMA_SLE_REQUIRE_SERIAL_NODE_ID
#if defined(RADAR_NODE_ID_CONFIG)
    if (!g_uart_config_ready) {
        (void)snprintf(g_uart_config_node_id, sizeof(g_uart_config_node_id), "%s", RADAR_NODE_ID_CONFIG);
        tdma_slave_sanitize_node_id(g_uart_config_node_id);
        g_uart_config_ready = (g_uart_config_node_id[0] != '\0');
        if (g_uart_config_ready) {
            PRINT("[SLAVE CFG] compile-time node id configured: %s\r\n", g_uart_config_node_id);
        }
    }
#endif
    uint32_t wait_log_ms = 0;
    PRINT("[SLAVE SLE] waiting for serial NODE=<unique_slave_id> before enable/scan\r\n");
    while (!g_uart_config_ready) {
        osal_msleep(50);
        g_tdma_tick_ms += 50;
        wait_log_ms += 50;
        if (wait_log_ms >= TDMA_SLE_SERIAL_WAIT_LOG_MS) {
            wait_log_ms = 0;
            PRINT("[SLAVE SLE] still waiting serial config, example: NODE=slave_01\r\n");
        }
    }
#else
    osal_msleep(5000);
#endif

    PRINT("[SLAVE SLE] enable client node=%s\r\n", radar_node_id());
    sle_seek_cbk_register();
    sle_connect_cbk_register();
    sle_ssapc_cbk_register();

    if (sle_announce_seek_register_callbacks(&g_seek_cbk) != ERRCODE_SUCC) {
        PRINT("[SLAVE SLE] announce/seek callback register failed\r\n");
        return -1;
    }

    if (sle_connection_register_callbacks(&g_connect_cbk) != ERRCODE_SUCC) {
        PRINT("[SLAVE SLE] connection callback register failed\r\n");
        return -1;
    }

    if (ssapc_register_callbacks(&g_ssapc_cbk) != ERRCODE_SUCC) {
        PRINT("[SLAVE SLE] SSAPC callback register failed\r\n");
        return -1;
    }

    radar_node_identity_init("before_enable_sle");

    if (enable_sle() != ERRCODE_SUCC) {
        PRINT("[SLAVE SLE] enable failed\r\n");
        return -1;
    }

    return 0;
}

static int tdma_sle_slave_task(const char *arg)
{
    unused(arg);
    while (1) {
        osal_msleep(50);
        g_tdma_tick_ms += 50;
    }
    return 0;
}

static void radar_slave_start_runtime_tasks(void)
{
    if (g_slave_runtime_started) {
        return;
    }
    if (!g_uart_config_ready) {
        return;
    }
    g_slave_runtime_started = true;

    PRINT("[SLAVE BOOT] NODE config accepted: %s; starting TDMA/SLE/radar tasks\r\n", g_uart_config_node_id);

    osal_task *tdma_task_handle = osal_kthread_create((osal_kthread_handler)tdma_sle_slave_task,
                                                       0,
                                                       "TDMASleSlaveTask",
                                                       TDMA_SLE_TASK_STACK_SIZE);
    if (tdma_task_handle != NULL) {
        osal_kthread_set_priority(tdma_task_handle, TDMA_SLE_TASK_PRIO);
        PRINT("[SLAVE TDMA] task created prio=%d stack=0x%x\r\n", TDMA_SLE_TASK_PRIO, TDMA_SLE_TASK_STACK_SIZE);
        osal_kfree(tdma_task_handle);
    } else {
        PRINT("[SLAVE TDMA] task create failed\r\n");
    }

    osal_task *sle_task_handle = osal_kthread_create((osal_kthread_handler)radar_sle_client_task,
                                                      0,
                                                      "RadarSleSlaveTask",
                                                      SLE_CLIENT_STACK_SIZE);
    if (sle_task_handle != NULL) {
        osal_kthread_set_priority(sle_task_handle, SLE_CLIENT_TASK_PRIO);
        PRINT("[SLAVE] SLE task created prio=%d stack=0x%x\r\n", SLE_CLIENT_TASK_PRIO, SLE_CLIENT_STACK_SIZE);
        osal_kfree(sle_task_handle);
    } else {
        PRINT("[SLAVE] SLE task create failed\r\n");
    }

    osal_task *radar_task_handle = osal_kthread_create((osal_kthread_handler)radar_task,
                                                        0,
                                                        "RadarDetectTask",
                                                        RADAR_TASK_STACK_SIZE);
    if (radar_task_handle != NULL) {
        osal_kthread_set_priority(radar_task_handle, RADAR_TASK_PRIO);
        PRINT("[SLAVE] radar task created prio=%d stack=0x%x\r\n", RADAR_TASK_PRIO, RADAR_TASK_STACK_SIZE);
        osal_kfree(radar_task_handle);
    } else {
        PRINT("[SLAVE] radar task create failed\r\n");
    }
}

static void radar_sle_slave_entry(void)
{
    uapi_watchdog_disable();
    printf("[SLAVE] entry, base_node=%s, watchdog disabled; waiting serial NODE config before all runtime tasks\r\n",
           RADAR_NODE_ID_BASE);
    tdma_sle_scheduler_init(&g_tdma_sched, 0, TDMA_SLE_SLOT_MS, TDMA_SLE_FRAME_SLOTS);
    g_tdma_my_slot = TDMA_SLE_INVALID_SLOT;
    printf("[SLAVE TDMA] scheduler init frame_slots=%u slot_ms=%u; TDMA/SLE/radar tasks are blocked until NODE is configured\r\n",
           g_tdma_frame_slots, TDMA_SLE_SLOT_MS);

#if defined(RADAR_NODE_ID_CONFIG)
    if (!g_uart_config_ready) {
        (void)snprintf(g_uart_config_node_id, sizeof(g_uart_config_node_id), "%s", RADAR_NODE_ID_CONFIG);
        tdma_slave_sanitize_node_id(g_uart_config_node_id);
        g_uart_config_ready = (g_uart_config_node_id[0] != '\0');
        if (g_uart_config_ready) {
            PRINT("[SLAVE CFG] compile-time node id configured: %s\r\n", g_uart_config_node_id);
            radar_slave_start_runtime_tasks();
            return;
        }
    }
#endif

    osal_task *uart_cfg_task_handle = NULL;

    osal_kthread_lock();
    uart_cfg_task_handle = osal_kthread_create((osal_kthread_handler)radar_slave_uart_config_task,
                                               0,
                                               "RadarSlaveCfgTask",
                                               TDMA_SLE_UART_CONFIG_STACK_SIZE);
    if (uart_cfg_task_handle != NULL) {
        osal_kthread_set_priority(uart_cfg_task_handle, TDMA_SLE_UART_CONFIG_PRIO);
        printf("[SLAVE CFG] UART config task created prio=%d stack=0x%x; waiting NODE=slave_01 / NODE=slave_02\r\n",
               TDMA_SLE_UART_CONFIG_PRIO, TDMA_SLE_UART_CONFIG_STACK_SIZE);
        osal_kfree(uart_cfg_task_handle);
    } else {
        printf("[SLAVE CFG] UART config task create failed\r\n");
    }
    osal_kthread_unlock();
}

app_run(radar_sle_slave_entry);
