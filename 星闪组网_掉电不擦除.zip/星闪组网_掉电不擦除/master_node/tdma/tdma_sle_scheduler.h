#ifndef TDMA_SLE_SCHEDULER_H_
#define TDMA_SLE_SCHEDULER_H_

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define TDMA_SLE_MIN_FRAME_SLOTS    8U
#define TDMA_SLE_FRAME_SLOT_STEP    8U
#define TDMA_SLE_MAX_FRAME_SLOTS    32U
#define TDMA_SLE_MAX_NODES          (TDMA_SLE_MAX_FRAME_SLOTS - 1U)
#define TDMA_SLE_MAX_NODE_ID_LEN    32U
#define TDMA_SLE_MASTER_SLOT        0U
#define TDMA_SLE_INVALID_SLOT       0xFFU

/*
 * Lightweight TDMA scheduler adapted from the UWB tdma_handler module in 2.zip.
 * The original UWB code depends on Decawave timestamping/event APIs.  This SLE
 * version keeps the same concepts: fixed frame length, slot duration, node table,
 * automatic node admission, and one node owning one or more slots in a frame.
 */
typedef struct {
    char node_id[TDMA_SLE_MAX_NODE_ID_LEN];
    uint8_t slot;
    uint32_t last_seen_ms;
    uint32_t last_seq;
    uint16_t conn_id;
    bool active;
} tdma_sle_node_t;

typedef struct {
    uint32_t frame_start_ms;
    uint16_t slot_duration_ms;
    uint8_t frame_slots;
    tdma_sle_node_t nodes[TDMA_SLE_MAX_NODES];
} tdma_sle_scheduler_t;

void tdma_sle_scheduler_init(tdma_sle_scheduler_t *sched,
                             uint32_t now_ms,
                             uint16_t slot_duration_ms,
                             uint8_t frame_slots);

uint8_t tdma_sle_current_slot(const tdma_sle_scheduler_t *sched, uint32_t now_ms);
uint32_t tdma_sle_next_slot_delay_ms(const tdma_sle_scheduler_t *sched,
                                     uint32_t now_ms,
                                     uint8_t slot);

uint8_t tdma_sle_hash_slot(const char *node_id, uint8_t frame_slots);
uint8_t tdma_sle_find_or_assign_slot(tdma_sle_scheduler_t *sched,
                                     const char *node_id,
                                     uint32_t now_ms,
                                     uint32_t seq,
                                     uint8_t preferred_slot);

uint8_t tdma_sle_find_or_assign_slot_ex(tdma_sle_scheduler_t *sched,
                                        const char *node_id,
                                        uint16_t conn_id,
                                        uint32_t now_ms,
                                        uint32_t seq,
                                        uint8_t preferred_slot);

uint8_t tdma_sle_active_count(const tdma_sle_scheduler_t *sched);
bool tdma_sle_expand_frame(tdma_sle_scheduler_t *sched);

void tdma_sle_mark_seen(tdma_sle_scheduler_t *sched,
                        const char *node_id,
                        uint32_t now_ms,
                        uint32_t seq);

void tdma_sle_expire_nodes(tdma_sle_scheduler_t *sched,
                           uint32_t now_ms,
                           uint32_t timeout_ms);

void tdma_sle_remove_node(tdma_sle_scheduler_t *sched, const char *node_id);
void tdma_sle_remove_nodes_by_conn_suffix(tdma_sle_scheduler_t *sched, uint16_t conn_id);
uint8_t tdma_sle_get_assigned_slot(const tdma_sle_scheduler_t *sched, const char *node_id);

bool tdma_sle_slot_is_owned_by(const tdma_sle_scheduler_t *sched,
                               const char *node_id,
                               uint8_t slot);

int tdma_sle_make_join_payload(char *buf,
                               uint16_t buf_len,
                               const char *node_id,
                               uint32_t seq,
                               uint8_t preferred_slot,
                               uint8_t frame_slots,
                               uint16_t slot_duration_ms);

int tdma_sle_make_assign_payload(char *buf,
                                uint16_t buf_len,
                                const char *node_id,
                                uint8_t assigned_slot,
                                uint8_t frame_slots,
                                uint16_t slot_duration_ms,
                                uint32_t seq);

int tdma_sle_make_radar_ack_payload(char *buf,
                                    uint16_t buf_len,
                                    const char *node_id,
                                    uint8_t slot,
                                    uint8_t frame_slots,
                                    uint32_t seq);

bool tdma_sle_parse_assign_payload(const char *payload,
                                   char *node_id,
                                   uint16_t node_id_len,
                                   uint8_t *slot,
                                   uint8_t *frame_slots);

int tdma_sle_make_radar_payload(char *buf,
                                uint16_t buf_len,
                                const char *node_id,
                                uint8_t slot,
                                uint8_t frame_slots,
                                uint8_t human,
                                uint16_t lower_boundary,
                                uint16_t upper_boundary,
                                uint32_t seq);

bool tdma_sle_parse_node_seq_slot(const char *payload,
                                  char *node_id,
                                  uint16_t node_id_len,
                                  uint32_t *seq,
                                  uint8_t *slot);

#ifdef __cplusplus
}
#endif

#endif /* TDMA_SLE_SCHEDULER_H_ */
