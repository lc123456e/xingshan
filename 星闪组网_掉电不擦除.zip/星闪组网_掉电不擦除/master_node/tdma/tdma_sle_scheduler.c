#include "tdma_sle_scheduler.h"

#include <stdio.h>
#include <string.h>

#ifndef EOK
#define EOK 0
#endif

static void tdma_safe_copy_node(char *dst, uint16_t dst_len, const char *src)
{
    if (dst == NULL || dst_len == 0) {
        return;
    }
    dst[0] = '\0';
    if (src == NULL) {
        return;
    }
    (void)snprintf(dst, dst_len, "%s", src);
}

void tdma_sle_scheduler_init(tdma_sle_scheduler_t *sched,
                             uint32_t now_ms,
                             uint16_t slot_duration_ms,
                             uint8_t frame_slots)
{
    if (sched == NULL) {
        return;
    }
    (void)memset(sched, 0, sizeof(*sched));
    sched->frame_start_ms = now_ms;
    sched->slot_duration_ms = (slot_duration_ms == 0U) ? 500U : slot_duration_ms;
    sched->frame_slots = (frame_slots < TDMA_SLE_MIN_FRAME_SLOTS) ? TDMA_SLE_MIN_FRAME_SLOTS : frame_slots;
    if (sched->frame_slots > TDMA_SLE_MAX_FRAME_SLOTS) {
        sched->frame_slots = TDMA_SLE_MAX_FRAME_SLOTS;
    }
}

uint8_t tdma_sle_current_slot(const tdma_sle_scheduler_t *sched, uint32_t now_ms)
{
    if (sched == NULL || sched->slot_duration_ms == 0U || sched->frame_slots == 0U) {
        return TDMA_SLE_MASTER_SLOT;
    }
    uint32_t elapsed = now_ms - sched->frame_start_ms;
    uint32_t frame_ms = (uint32_t)sched->slot_duration_ms * sched->frame_slots;
    if (frame_ms == 0U) {
        return TDMA_SLE_MASTER_SLOT;
    }
    return (uint8_t)((elapsed % frame_ms) / sched->slot_duration_ms);
}

uint32_t tdma_sle_next_slot_delay_ms(const tdma_sle_scheduler_t *sched,
                                     uint32_t now_ms,
                                     uint8_t slot)
{
    if (sched == NULL || sched->slot_duration_ms == 0U || sched->frame_slots == 0U) {
        return 0U;
    }
    if (slot >= sched->frame_slots) {
        slot = TDMA_SLE_MASTER_SLOT;
    }
    uint32_t elapsed = now_ms - sched->frame_start_ms;
    uint32_t frame_ms = (uint32_t)sched->slot_duration_ms * sched->frame_slots;
    uint32_t pos = elapsed % frame_ms;
    uint32_t target = (uint32_t)slot * sched->slot_duration_ms;
    if (pos <= target) {
        return target - pos;
    }
    return frame_ms - pos + target;
}

uint8_t tdma_sle_hash_slot(const char *node_id, uint8_t frame_slots)
{
    uint32_t hash = 2166136261UL;
    const unsigned char *p = (const unsigned char *)node_id;
    if (frame_slots < 2U) {
        return 1U;
    }
    while (p != NULL && *p != '\0') {
        hash ^= (uint32_t)(*p++);
        hash *= 16777619UL;
    }
    /* Slot 0 is reserved as master/beacon/join guard slot. */
    return (uint8_t)(1U + (hash % (frame_slots - 1U)));
}

static int find_node_index(const tdma_sle_scheduler_t *sched, const char *node_id)
{
    if (sched == NULL || node_id == NULL) {
        return -1;
    }
    for (uint8_t i = 0; i < TDMA_SLE_MAX_NODES; i++) {
        if (sched->nodes[i].active && strcmp(sched->nodes[i].node_id, node_id) == 0) {
            return (int)i;
        }
    }
    return -1;
}

uint8_t tdma_sle_active_count(const tdma_sle_scheduler_t *sched)
{
    uint8_t count = 0;
    if (sched == NULL) {
        return 0;
    }
    for (uint8_t i = 0; i < TDMA_SLE_MAX_NODES; i++) {
        if (sched->nodes[i].active) {
            count++;
        }
    }
    return count;
}

bool tdma_sle_expand_frame(tdma_sle_scheduler_t *sched)
{
    if (sched == NULL) {
        return false;
    }
    if (sched->frame_slots >= TDMA_SLE_MAX_FRAME_SLOTS) {
        return false;
    }
    uint8_t next = (uint8_t)(sched->frame_slots + TDMA_SLE_FRAME_SLOT_STEP);
    if (next > TDMA_SLE_MAX_FRAME_SLOTS) {
        next = TDMA_SLE_MAX_FRAME_SLOTS;
    }
    sched->frame_slots = next;
    return true;
}

static bool slot_used(const tdma_sle_scheduler_t *sched, uint8_t slot)
{
    if (sched == NULL) {
        return false;
    }
    for (uint8_t i = 0; i < TDMA_SLE_MAX_NODES; i++) {
        if (sched->nodes[i].active && sched->nodes[i].slot == slot) {
            return true;
        }
    }
    return false;
}

uint8_t tdma_sle_find_or_assign_slot_ex(tdma_sle_scheduler_t *sched,
                                        const char *node_id,
                                        uint16_t conn_id,
                                        uint32_t now_ms,
                                        uint32_t seq,
                                        uint8_t preferred_slot)
{
    if (sched == NULL || node_id == NULL || sched->frame_slots < 2U) {
        return TDMA_SLE_INVALID_SLOT;
    }

    int idx = find_node_index(sched, node_id);
    if (idx >= 0) {
        sched->nodes[idx].last_seen_ms = now_ms;
        sched->nodes[idx].last_seq = seq;
        sched->nodes[idx].conn_id = conn_id;
        return sched->nodes[idx].slot;
    }

    while (1) {
        uint8_t base = preferred_slot;
        if (base == TDMA_SLE_INVALID_SLOT || base == TDMA_SLE_MASTER_SLOT || base >= sched->frame_slots) {
            base = 1U;
        }

        uint8_t assigned = TDMA_SLE_INVALID_SLOT;
        for (uint8_t offset = 0; offset < sched->frame_slots - 1U; offset++) {
            uint8_t candidate = (uint8_t)(1U + ((base - 1U + offset) % (sched->frame_slots - 1U)));
            if (!slot_used(sched, candidate)) {
                assigned = candidate;
                break;
            }
        }

        if (assigned != TDMA_SLE_INVALID_SLOT) {
            for (uint8_t i = 0; i < TDMA_SLE_MAX_NODES; i++) {
                if (!sched->nodes[i].active) {
                    sched->nodes[i].active = true;
                    tdma_safe_copy_node(sched->nodes[i].node_id, TDMA_SLE_MAX_NODE_ID_LEN, node_id);
                    sched->nodes[i].slot = assigned;
                    sched->nodes[i].last_seen_ms = now_ms;
                    sched->nodes[i].last_seq = seq;
                    sched->nodes[i].conn_id = conn_id;
                    return assigned;
                }
            }
            return TDMA_SLE_INVALID_SLOT;
        }

        if (!tdma_sle_expand_frame(sched)) {
            return TDMA_SLE_INVALID_SLOT;
        }
    }
}

uint8_t tdma_sle_find_or_assign_slot(tdma_sle_scheduler_t *sched,
                                     const char *node_id,
                                     uint32_t now_ms,
                                     uint32_t seq,
                                     uint8_t preferred_slot)
{
    return tdma_sle_find_or_assign_slot_ex(sched, node_id, 0xFFFFU, now_ms, seq, preferred_slot);
}

void tdma_sle_mark_seen(tdma_sle_scheduler_t *sched,
                        const char *node_id,
                        uint32_t now_ms,
                        uint32_t seq)
{
    int idx = find_node_index(sched, node_id);
    if (idx >= 0) {
        sched->nodes[idx].last_seen_ms = now_ms;
        sched->nodes[idx].last_seq = seq;
    }
}


void tdma_sle_remove_node(tdma_sle_scheduler_t *sched, const char *node_id)
{
    int idx = find_node_index(sched, node_id);
    if (idx >= 0) {
        (void)memset(&sched->nodes[idx], 0, sizeof(sched->nodes[idx]));
    }
}

void tdma_sle_remove_nodes_by_conn_suffix(tdma_sle_scheduler_t *sched, uint16_t conn_id)
{
    if (sched == NULL) {
        return;
    }
    for (uint8_t i = 0; i < TDMA_SLE_MAX_NODES; i++) {
        if (sched->nodes[i].active && sched->nodes[i].conn_id == conn_id) {
            (void)memset(&sched->nodes[i], 0, sizeof(sched->nodes[i]));
        }
    }
}

uint8_t tdma_sle_get_assigned_slot(const tdma_sle_scheduler_t *sched, const char *node_id)
{
    int idx = find_node_index(sched, node_id);
    if (idx < 0) {
        return TDMA_SLE_INVALID_SLOT;
    }
    return sched->nodes[idx].slot;
}

void tdma_sle_expire_nodes(tdma_sle_scheduler_t *sched,
                           uint32_t now_ms,
                           uint32_t timeout_ms)
{
    if (sched == NULL || timeout_ms == 0U) {
        return;
    }
    for (uint8_t i = 0; i < TDMA_SLE_MAX_NODES; i++) {
        if (sched->nodes[i].active && (now_ms - sched->nodes[i].last_seen_ms) > timeout_ms) {
            (void)memset(&sched->nodes[i], 0, sizeof(sched->nodes[i]));
        }
    }
}

bool tdma_sle_slot_is_owned_by(const tdma_sle_scheduler_t *sched,
                               const char *node_id,
                               uint8_t slot)
{
    int idx = find_node_index(sched, node_id);
    if (idx < 0) {
        return false;
    }
    return sched->nodes[idx].slot == slot;
}

int tdma_sle_make_join_payload(char *buf,
                               uint16_t buf_len,
                               const char *node_id,
                               uint32_t seq,
                               uint8_t preferred_slot,
                               uint8_t frame_slots,
                               uint16_t slot_duration_ms)
{
    if (buf == NULL || buf_len == 0U || node_id == NULL) {
        return -1;
    }
    return snprintf(buf, buf_len,
                    "JOIN,node=%s,slot=%u,frame=%u,sd=%u,seq=%lu",
                    node_id,
                    (unsigned int)preferred_slot,
                    (unsigned int)frame_slots,
                    (unsigned int)slot_duration_ms,
                    (unsigned long)seq);
}

int tdma_sle_make_assign_payload(char *buf,
                                uint16_t buf_len,
                                const char *node_id,
                                uint8_t assigned_slot,
                                uint8_t frame_slots,
                                uint16_t slot_duration_ms,
                                uint32_t seq)
{
    if (buf == NULL || buf_len == 0U || node_id == NULL) {
        return -1;
    }
    return snprintf(buf, buf_len,
                    "ASSIGN,node=%s,slot=%u,frame=%u,sd=%u,cmd=RADAR,seq=%lu",
                    node_id,
                    (unsigned int)assigned_slot,
                    (unsigned int)frame_slots,
                    (unsigned int)slot_duration_ms,
                    (unsigned long)seq);
}

int tdma_sle_make_radar_ack_payload(char *buf,
                                    uint16_t buf_len,
                                    const char *node_id,
                                    uint8_t slot,
                                    uint8_t frame_slots,
                                    uint32_t seq)
{
    if (buf == NULL || buf_len == 0U || node_id == NULL) {
        return -1;
    }
    return snprintf(buf, buf_len,
                    "RADARACK,node=%s,slot=%u,frame=%u,seq=%lu",
                    node_id,
                    (unsigned int)slot,
                    (unsigned int)frame_slots,
                    (unsigned long)seq);
}

bool tdma_sle_parse_assign_payload(const char *payload,
                                   char *node_id,
                                   uint16_t node_id_len,
                                   uint8_t *slot,
                                   uint8_t *frame_slots)
{
    char parsed_node[TDMA_SLE_MAX_NODE_ID_LEN] = {0};
    unsigned int parsed_slot = TDMA_SLE_INVALID_SLOT;
    unsigned int parsed_frame = 0U;
    if (payload == NULL) {
        return false;
    }
    if (sscanf(payload, "ASSIGN,node=%31[^,],slot=%u,frame=%u,sd=%*u,cmd=RADAR,seq=%*lu",
               parsed_node, &parsed_slot, &parsed_frame) < 3) {
        return false;
    }
    if (node_id != NULL && node_id_len > 0U) {
        tdma_safe_copy_node(node_id, node_id_len, parsed_node);
    }
    if (slot != NULL) {
        *slot = (uint8_t)parsed_slot;
    }
    if (frame_slots != NULL) {
        *frame_slots = (uint8_t)parsed_frame;
    }
    return true;
}

int tdma_sle_make_radar_payload(char *buf,
                                uint16_t buf_len,
                                const char *node_id,
                                uint8_t slot,
                                uint8_t frame_slots,
                                uint8_t human,
                                uint16_t lower_boundary,
                                uint16_t upper_boundary,
                                uint32_t seq)
{
    if (buf == NULL || buf_len == 0U || node_id == NULL) {
        return -1;
    }
    return snprintf(buf, buf_len,
                    "RADAR,node=%s,slot=%u,frame=%u,human=%u,lb=%u,hb=%u,seq=%lu",
                    node_id,
                    (unsigned int)slot,
                    (unsigned int)frame_slots,
                    (unsigned int)human,
                    (unsigned int)lower_boundary,
                    (unsigned int)upper_boundary,
                    (unsigned long)seq);
}

bool tdma_sle_parse_node_seq_slot(const char *payload,
                                  char *node_id,
                                  uint16_t node_id_len,
                                  uint32_t *seq,
                                  uint8_t *slot)
{
    char parsed_node[TDMA_SLE_MAX_NODE_ID_LEN] = {0};
    unsigned int parsed_slot = TDMA_SLE_INVALID_SLOT;
    unsigned long parsed_seq = 0UL;

    if (payload == NULL) {
        return false;
    }

    if (sscanf(payload, "RADAR,node=%31[^,],slot=%u,frame=%*u,human=%*u,lb=%*u,hb=%*u,seq=%lu",
               parsed_node, &parsed_slot, &parsed_seq) < 3) {
        if (sscanf(payload, "JOIN,node=%31[^,],slot=%u,frame=%*u,sd=%*u,seq=%lu",
                   parsed_node, &parsed_slot, &parsed_seq) < 3) {
            if (sscanf(payload, "RADAR,node=%31[^,],human=%*u,lb=%*u,hb=%*u,seq=%lu",
                       parsed_node, &parsed_seq) < 2) {
                return false;
            }
            parsed_slot = TDMA_SLE_INVALID_SLOT;
        }
    }

    if (node_id != NULL && node_id_len > 0U) {
        tdma_safe_copy_node(node_id, node_id_len, parsed_node);
    }
    if (seq != NULL) {
        *seq = (uint32_t)parsed_seq;
    }
    if (slot != NULL) {
        *slot = (uint8_t)parsed_slot;
    }
    return true;
}
