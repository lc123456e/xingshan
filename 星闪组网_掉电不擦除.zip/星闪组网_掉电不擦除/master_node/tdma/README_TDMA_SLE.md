# TDMA-SLE integration notes

This project keeps the UWB TDMA implementation from `2.zip` under `common/tdma/uwb_reference/` for reference.  The UWB source cannot be linked directly into the SLE radar project because it depends on Decawave/UWB runtime symbols such as `instance_get_local_structure_ptr`, `portGetTickCntMicro`, and `dwt_*` timestamp APIs.

The active integration is `tdma_sle_scheduler.c/.h`.  It ports the usable TDMA ideas into the SLE project:

- slot 0 is reserved for master/beacon/join guard work;
- slave nodes compute a preferred slot from their node id and send a `JOIN` payload after SLE service discovery;
- the master keeps a TDMA node table and admits new nodes into the first free slot at or after the preferred slot;
- each radar report carries `node`, `slot`, `frame`, and `seq` fields;
- each slave gates radar writes so they occur only inside its TDMA slot;
- the master validates/records the slot owner before forwarding radar data to MQTT.

Default frame settings are 8 slots x 500 ms.  Change `TDMA_SLE_FRAME_SLOTS` and `TDMA_SLE_SLOT_MS` in master/slave source if a different frame is required.
